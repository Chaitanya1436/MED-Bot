# This file is currently empty as we're not using a database
# for this application. It's included for potential future expansion
# when we might want to store user data, chat history, or medical information.

# If needed, we could add models for:
# - Users
# - ChatSessions
# - Symptoms
# - Diseases
# - Specialists
