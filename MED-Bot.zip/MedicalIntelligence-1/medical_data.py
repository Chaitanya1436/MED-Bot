"""
Medical data and prediction functionalities for the medical chatbot.
"""

import logging
import random
from collections import defaultdict

# Initialize logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Mapping of symptoms to possible diseases with probability weights
# This is a simplified version for demonstration purposes
# In a real system, this would be replaced with a trained ML model
SYMPTOM_DISEASE_MAP = {
    "fever": {
        "Common Cold": 60,
        "Influenza": 70,
        "COVID-19": 60,
        "Pneumonia": 40,
        "Urinary Tract Infection": 30,
        "Dengue Fever": 50
    },
    "cough": {
        "Common Cold": 80,
        "Influenza": 70,
        "COVID-19": 80,
        "Pneumonia": 70,
        "Bronchitis": 90,
        "Asthma": 60
    },
    "headache": {
        "Migraine": 90,
        "Tension Headache": 80,
        "Sinusitis": 70,
        "Common Cold": 50,
        "Influenza": 60,
        "Meningitis": 30
    },
    "nausea": {
        "Food Poisoning": 80,
        "Gastroenteritis": 70,
        "Migraine": 40,
        "Morning Sickness": 60,
        "Motion Sickness": 70,
        "Appendicitis": 40
    },
    "fatigue": {
        "Anemia": 70,
        "Chronic Fatigue Syndrome": 90,
        "Depression": 60,
        "Hypothyroidism": 70,
        "Influenza": 60,
        "COVID-19": 60
    },
    "dizziness": {
        "Vertigo": 90,
        "Low Blood Pressure": 70,
        "Anemia": 60,
        "Dehydration": 60,
        "Migraine": 50,
        "Inner Ear Infection": 80
    },
    "vomiting": {
        "Food Poisoning": 90,
        "Gastroenteritis": 80,
        "Migraine": 40,
        "Appendicitis": 50,
        "Morning Sickness": 70,
        "Motion Sickness": 80
    },
    "diarrhea": {
        "Food Poisoning": 80,
        "Gastroenteritis": 90,
        "Irritable Bowel Syndrome": 70,
        "Crohn's Disease": 60,
        "Ulcerative Colitis": 60,
        "Celiac Disease": 50
    },
    "chest pain": {
        "Angina": 80,
        "Myocardial Infarction": 70,
        "Gastroesophageal Reflux Disease": 60,
        "Pneumonia": 50,
        "Pulmonary Embolism": 40,
        "Costochondritis": 50
    },
    "shortness of breath": {
        "Asthma": 80,
        "Chronic Obstructive Pulmonary Disease": 70,
        "Pneumonia": 60,
        "Pulmonary Embolism": 50,
        "Heart Failure": 60,
        "COVID-19": 60
    },
    "sore throat": {
        "Pharyngitis": 90,
        "Tonsillitis": 80,
        "Common Cold": 70,
        "Influenza": 60,
        "Strep Throat": 70,
        "Laryngitis": 60
    },
    "runny nose": {
        "Common Cold": 90,
        "Allergic Rhinitis": 80,
        "Sinusitis": 70,
        "Influenza": 60,
        "Respiratory Syncytial Virus": 50
    },
    "muscle pain": {
        "Fibromyalgia": 80,
        "Influenza": 70,
        "COVID-19": 60,
        "Polymyalgia Rheumatica": 60,
        "Rhabdomyolysis": 30,
        "Chronic Fatigue Syndrome": 50
    },
    "joint pain": {
        "Rheumatoid Arthritis": 80,
        "Osteoarthritis": 70,
        "Gout": 60,
        "Lupus": 50,
        "Lyme Disease": 40,
        "Psoriatic Arthritis": 50
    },
    "rash": {
        "Contact Dermatitis": 80,
        "Atopic Dermatitis": 70,
        "Psoriasis": 60,
        "Rosacea": 50,
        "Eczema": 70,
        "Chickenpox": 60
    },
    "abdominal pain": {
        "Appendicitis": 60,
        "Gastritis": 70,
        "Irritable Bowel Syndrome": 60,
        "Gastroenteritis": 70,
        "Peptic Ulcer": 60,
        "Pancreatitis": 50
    },
    "back pain": {
        "Herniated Disc": 70,
        "Muscle Strain": 80,
        "Osteoarthritis": 60,
        "Kidney Stones": 50,
        "Sciatica": 70,
        "Spondylosis": 60
    },
    "loss of appetite": {
        "Depression": 60,
        "Gastritis": 70,
        "Hepatitis": 60,
        "Cancer": 40,
        "Hypothyroidism": 50,
        "Anorexia Nervosa": 70
    },
    "weight loss": {
        "Hyperthyroidism": 70,
        "Diabetes": 60,
        "Depression": 50,
        "Cancer": 40,
        "Inflammatory Bowel Disease": 60,
        "Tuberculosis": 40
    },
    "insomnia": {
        "Anxiety Disorder": 80,
        "Depression": 70,
        "Sleep Apnea": 60,
        "Restless Leg Syndrome": 60,
        "Hyperthyroidism": 50,
        "Stress": 70
    },
    "anxiety": {
        "Generalized Anxiety Disorder": 90,
        "Panic Disorder": 80,
        "Social Anxiety Disorder": 70,
        "Post-Traumatic Stress Disorder": 60,
        "Obsessive-Compulsive Disorder": 60,
        "Phobia": 70
    },
    "depression": {
        "Major Depressive Disorder": 90,
        "Bipolar Disorder": 70,
        "Dysthymia": 80,
        "Seasonal Affective Disorder": 60,
        "Postpartum Depression": 60,
        "Adjustment Disorder": 70
    },
    "blurred vision": {
        "Myopia": 70,
        "Hyperopia": 60,
        "Astigmatism": 60,
        "Cataract": 70,
        "Glaucoma": 60,
        "Macular Degeneration": 50
    },
    "ear pain": {
        "Otitis Media": 80,
        "Otitis Externa": 70,
        "Eustachian Tube Dysfunction": 60,
        "Temporomandibular Joint Disorder": 50,
        "Sinusitis": 40,
        "Ear Infection": 90
    },
    "difficulty swallowing": {
        "Esophagitis": 70,
        "Gastroesophageal Reflux Disease": 60,
        "Pharyngitis": 50,
        "Tonsillitis": 60,
        "Esophageal Cancer": 30,
        "Globus Sensation": 50
    },
    "swelling": {
        "Edema": 80,
        "Inflammation": 70,
        "Lymphedema": 60,
        "Cellulitis": 50,
        "Allergic Reaction": 60,
        "Injury": 70
    },
    "numbness": {
        "Peripheral Neuropathy": 80,
        "Multiple Sclerosis": 60,
        "Stroke": 50,
        "Carpal Tunnel Syndrome": 70,
        "Vitamin B12 Deficiency": 60,
        "Herniated Disc": 60
    },
    "tingling": {
        "Peripheral Neuropathy": 80,
        "Multiple Sclerosis": 60,
        "Carpal Tunnel Syndrome": 70,
        "Vitamin B12 Deficiency": 60,
        "Raynaud's Phenomenon": 50,
        "Diabetes": 50
    },
    "tremor": {
        "Parkinson's Disease": 80,
        "Essential Tremor": 70,
        "Multiple Sclerosis": 50,
        "Anxiety Disorder": 60,
        "Hyperthyroidism": 50,
        "Medication Side Effect": 60
    },
    "sweating": {
        "Hyperhidrosis": 80,
        "Menopause": 70,
        "Hyperthyroidism": 60,
        "Anxiety Disorder": 60,
        "Infection": 50,
        "Tuberculosis": 40
    },
    "chills": {
        "Influenza": 80,
        "Pneumonia": 70,
        "Malaria": 60,
        "Urinary Tract Infection": 50,
        "Sepsis": 40,
        "Common Cold": 70
    }
}

# Mapping of diseases to medical specialists
DISEASE_SPECIALIST_MAP = {
    # Cardiovascular
    "Angina": "Cardiologist",
    "Myocardial Infarction": "Cardiologist",
    "Heart Failure": "Cardiologist",
    
    # Respiratory
    "Asthma": "Pulmonologist",
    "Chronic Obstructive Pulmonary Disease": "Pulmonologist",
    "Pneumonia": "Pulmonologist",
    "Bronchitis": "Pulmonologist",
    "Respiratory Syncytial Virus": "Pulmonologist",
    "Pulmonary Embolism": "Pulmonologist",
    
    # Gastrointestinal
    "Gastroenteritis": "Gastroenterologist",
    "Irritable Bowel Syndrome": "Gastroenterologist",
    "Crohn's Disease": "Gastroenterologist",
    "Ulcerative Colitis": "Gastroenterologist",
    "Celiac Disease": "Gastroenterologist",
    "Gastroesophageal Reflux Disease": "Gastroenterologist",
    "Gastritis": "Gastroenterologist",
    "Peptic Ulcer": "Gastroenterologist",
    "Pancreatitis": "Gastroenterologist",
    "Appendicitis": "General Surgeon",
    "Inflammatory Bowel Disease": "Gastroenterologist",
    "Esophagitis": "Gastroenterologist",
    "Food Poisoning": "General Practitioner",
    
    # Neurological
    "Migraine": "Neurologist",
    "Tension Headache": "Neurologist",
    "Vertigo": "Neurologist",
    "Multiple Sclerosis": "Neurologist",
    "Parkinson's Disease": "Neurologist",
    "Stroke": "Neurologist",
    "Meningitis": "Neurologist",
    "Peripheral Neuropathy": "Neurologist",
    "Essential Tremor": "Neurologist",
    
    # Psychiatric
    "Depression": "Psychiatrist",
    "Anxiety Disorder": "Psychiatrist",
    "Generalized Anxiety Disorder": "Psychiatrist",
    "Panic Disorder": "Psychiatrist",
    "Social Anxiety Disorder": "Psychiatrist",
    "Post-Traumatic Stress Disorder": "Psychiatrist",
    "Obsessive-Compulsive Disorder": "Psychiatrist",
    "Bipolar Disorder": "Psychiatrist",
    "Major Depressive Disorder": "Psychiatrist",
    "Dysthymia": "Psychiatrist",
    "Seasonal Affective Disorder": "Psychiatrist",
    "Postpartum Depression": "Psychiatrist",
    "Adjustment Disorder": "Psychiatrist",
    "Anorexia Nervosa": "Psychiatrist",
    "Stress": "Psychiatrist",
    "Phobia": "Psychiatrist",
    
    # Infectious Disease
    "Common Cold": "General Practitioner",
    "Influenza": "General Practitioner",
    "COVID-19": "Infectious Disease Specialist",
    "Sinusitis": "Otolaryngologist",
    "Pharyngitis": "Otolaryngologist",
    "Tonsillitis": "Otolaryngologist",
    "Strep Throat": "General Practitioner",
    "Laryngitis": "Otolaryngologist",
    "Urinary Tract Infection": "Urologist",
    "Dengue Fever": "Infectious Disease Specialist",
    "Malaria": "Infectious Disease Specialist",
    "Tuberculosis": "Pulmonologist",
    "Lyme Disease": "Infectious Disease Specialist",
    "Sepsis": "Emergency Medicine Physician",
    
    # Dermatological
    "Contact Dermatitis": "Dermatologist",
    "Atopic Dermatitis": "Dermatologist",
    "Psoriasis": "Dermatologist",
    "Rosacea": "Dermatologist",
    "Eczema": "Dermatologist",
    "Chickenpox": "General Practitioner",
    "Cellulitis": "Dermatologist",
    
    # Rheumatological
    "Rheumatoid Arthritis": "Rheumatologist",
    "Osteoarthritis": "Rheumatologist",
    "Gout": "Rheumatologist",
    "Lupus": "Rheumatologist",
    "Psoriatic Arthritis": "Rheumatologist",
    "Fibromyalgia": "Rheumatologist",
    "Polymyalgia Rheumatica": "Rheumatologist",
    
    # Endocrinological
    "Diabetes": "Endocrinologist",
    "Hypothyroidism": "Endocrinologist",
    "Hyperthyroidism": "Endocrinologist",
    
    # Hematological
    "Anemia": "Hematologist",
    
    # Ophthalmological
    "Myopia": "Ophthalmologist",
    "Hyperopia": "Ophthalmologist",
    "Astigmatism": "Ophthalmologist",
    "Cataract": "Ophthalmologist",
    "Glaucoma": "Ophthalmologist",
    "Macular Degeneration": "Ophthalmologist",
    "Blurred Vision": "Ophthalmologist",
    
    # Otolaryngological
    "Otitis Media": "Otolaryngologist",
    "Otitis Externa": "Otolaryngologist",
    "Eustachian Tube Dysfunction": "Otolaryngologist",
    "Allergic Rhinitis": "Allergist",
    "Inner Ear Infection": "Otolaryngologist",
    "Ear Infection": "Otolaryngologist",
    
    # Orthopedic
    "Herniated Disc": "Orthopedic Surgeon",
    "Muscle Strain": "Orthopedic Surgeon",
    "Sciatica": "Orthopedic Surgeon",
    "Spondylosis": "Orthopedic Surgeon",
    "Temporomandibular Joint Disorder": "Oral and Maxillofacial Surgeon",
    
    # Nephrological
    "Kidney Stones": "Nephrologist",
    "Edema": "Nephrologist",
    
    # Other
    "Chronic Fatigue Syndrome": "General Practitioner",
    "Low Blood Pressure": "Cardiologist",
    "Dehydration": "General Practitioner",
    "Morning Sickness": "Obstetrician",
    "Motion Sickness": "General Practitioner",
    "Rhabdomyolysis": "Nephrologist",
    "Costochondritis": "Rheumatologist",
    "Globus Sensation": "Otolaryngologist",
    "Inflammation": "General Practitioner",
    "Lymphedema": "Vascular Surgeon",
    "Allergic Reaction": "Allergist",
    "Injury": "Orthopedic Surgeon",
    "Carpal Tunnel Syndrome": "Orthopedic Surgeon",
    "Vitamin B12 Deficiency": "Hematologist",
    "Raynaud's Phenomenon": "Rheumatologist",
    "Medication Side Effect": "General Practitioner",
    "Hyperhidrosis": "Dermatologist",
    "Menopause": "Gynecologist",
    "Sleep Apnea": "Sleep Medicine Specialist",
    "Restless Leg Syndrome": "Neurologist",
    "Hepatitis": "Hepatologist",
    "Cancer": "Oncologist",
    "Esophageal Cancer": "Oncologist"
}

def predict_diseases(symptoms):
    """
    Predict potential diseases based on reported symptoms.
    
    Args:
        symptoms (list): List of symptoms reported by the user
        
    Returns:
        list: List of (disease, probability) tuples, sorted by probability
    """
    if not symptoms:
        return [("Insufficient symptoms to make a prediction", 0)]
    
    # Calculate scores for each disease
    disease_scores = defaultdict(int)
    
    # Sum up the weights for each disease based on the symptoms
    for symptom in symptoms:
        if symptom in SYMPTOM_DISEASE_MAP:
            for disease, weight in SYMPTOM_DISEASE_MAP[symptom].items():
                disease_scores[disease] += weight
    
    # Normalize scores based on number of symptoms
    disease_scores_normalized = {}
    for disease in disease_scores:
        # Base score on matching symptoms
        base_score = int(disease_scores[disease] / len(symptoms))
        
        # Adjust slightly to avoid deterministic results
        # This simulates the variance in real medical predictions
        adjustment = random.randint(-5, 5)
        # Keep scores as percentages internally but don't display them
        disease_scores_normalized[disease] = max(5, min(95, base_score + adjustment)) / 100
    
    # Replace the original dictionary with normalized scores
    disease_scores = disease_scores_normalized
    
    # Sort diseases by score in descending order
    sorted_diseases = sorted(disease_scores.items(), key=lambda x: x[1], reverse=True)
    
    # Return top matches
    return sorted_diseases[:5]

def recommend_specialist(diseases):
    """
    Recommend a medical specialist based on the predicted diseases.
    
    Args:
        diseases (list): List of (disease, probability) tuples
        
    Returns:
        str: Recommended medical specialist
    """
    if not diseases:
        return "General Practitioner"
    
    # Get the most likely disease
    top_disease = diseases[0][0]
    
    # Look up the specialist for this disease
    if top_disease in DISEASE_SPECIALIST_MAP:
        return DISEASE_SPECIALIST_MAP[top_disease]
    
    # Default recommendation
    return "General Practitioner"
