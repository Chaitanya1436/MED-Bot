import re
import string
import logging
from fuzzywuzzy import fuzz, process
import spacy
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.tag import pos_tag
from nltk.chunk import ne_chunk
import jellyfish  # For phonetic matching

# Download required NLTK resources
resources = [
    'punkt',
    'stopwords',
    'averaged_perceptron_tagger',
    'maxent_ne_chunker',
    'words'
]

for resource in resources:
    try:
        nltk.data.find(f'tokenizers/{resource}' if resource == 'punkt' else 
                      f'corpora/{resource}' if resource in ['stopwords', 'words'] else
                      f'taggers/{resource}' if resource == 'averaged_perceptron_tagger' else
                      f'chunkers/{resource}')
    except LookupError:
        nltk.download(resource)

# Ensure we have the correct tagger
try:
    nltk.data.find('taggers/averaged_perceptron_tagger')
except LookupError:
    nltk.download('averaged_perceptron_tagger')

# Initialize logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Load spaCy model
try:
    nlp = spacy.load("en_core_web_sm")
except OSError:
    # If model not found, attempt to download it
    import subprocess
    subprocess.run(["python", "-m", "spacy", "download", "en_core_web_sm"])
    try:
        nlp = spacy.load("en_core_web_sm")
    except OSError:
        logger.error("Failed to load spaCy model")
        # Fallback to a very basic NLP functionality
        nlp = None

class NLPProcessor:
    """Class for natural language processing of medical text"""
    
    def __init__(self):
        """Initialize the NLP processor with medical dictionaries"""
        # Common medical symptoms for matching (expanded list)
        self.symptoms = [
            # Common symptoms
            "fever", "cough", "headache", "nausea", "fatigue", 
            "dizziness", "vomiting", "diarrhea", "chest pain", "shortness of breath",
            "sore throat", "runny nose", "muscle pain", "joint pain", "rash",
            "abdominal pain", "stomach pain", "back pain", "loss of appetite", "weight loss", 
            "insomnia", "anxiety", "depression", "blurred vision", "ear pain", 
            "difficulty swallowing", "swelling", "numbness", "tingling", "tremor", 
            "sweating", "chills", "cold", "coughing", "sneezing", "congestion",
            "body ache", "stuffy nose", "wheezing", "itching", "skin rash", 
            "hives", "swollen glands", "dry cough", "wet cough", "phlegm", 
            "difficulty breathing", "rapid heartbeat", "high blood pressure", "low blood pressure", 
            "fainting", "difficulty sleeping", "excessive sleeping", "night sweats", 
            "hot flashes", "constipation", "gas", "bloating", "heartburn", 
            "indigestion", "stomach cramps",
            
            # More specific pain locations
            "neck pain", "shoulder pain", "elbow pain", "wrist pain", "hand pain",
            "finger pain", "hip pain", "knee pain", "ankle pain", "foot pain", 
            "toe pain", "lower back pain", "upper back pain", "middle back pain",
            "jaw pain", "facial pain", "eye pain", "temple pain", "sinus pain",
            "scalp pain", "throat pain", "chest tightness", "rib pain",
            
            # Digestive issues
            "acid reflux", "stomach ulcer", "irritable bowel", "bloody stool",
            "black stool", "food poisoning", "stomach flu", "appendicitis symptoms",
            "gallbladder pain", "liver pain", "jaundice", "upset stomach",
            "abdominal cramps", "difficulty digesting", "lactose intolerance",
            "gluten sensitivity", "bowel inflammation", "rectal bleeding",
            
            # Respiratory 
            "common cold", "flu symptoms", "bronchitis", "pneumonia symptoms",
            "asthma attack", "tuberculosis symptoms", "pleurisy", "emphysema",
            "lung infection", "chest infection", "sinus infection", "nasal congestion",
            "post nasal drip", "strep throat", "laryngitis", "tonsillitis",
            "pulmonary edema", "breathing difficulties", "shortness of breath",
            
            # Neurological
            "migraine", "cluster headache", "tension headache", "vertigo", 
            "memory loss", "confusion", "cognitive decline", "seizure", "epilepsy symptoms",
            "stroke symptoms", "facial drooping", "speech difficulty", "coordination problems",
            "balance issues", "paralysis", "weakness on one side", "numbness in face",
            "brain fog", "consciousness loss", "faintness", "disorientation",
            
            # Cardiovascular
            "heart attack symptoms", "irregular heartbeat", "arrhythmia", "heart palpitations",
            "high cholesterol", "circulation problems", "leg swelling", "varicose veins",
            "deep vein thrombosis", "anemia symptoms", "blood clots", "poor circulation",
            "hypertension", "hypotension", "lightheadedness", "bluish skin", "cyanosis",
            
            # Mental health
            "panic attack", "suicidal thoughts", "bipolar symptoms", "schizophrenia symptoms",
            "obsessive thoughts", "compulsive behavior", "post-traumatic stress",
            "social anxiety", "agoraphobia", "seasonal affective disorder", "mood swings",
            "irritability", "aggression", "personality changes", "eating disorder",
            
            # Sleep related
            "sleep apnea", "restless leg syndrome", "narcolepsy", "excessive daytime sleepiness",
            "sleep paralysis", "night terrors", "sleep walking", "insomnia", "chronic fatigue",
            "fatigue after sleeping", "snoring", "teeth grinding", "nightmares", "broken sleep",
            
            # Skin conditions
            "eczema", "psoriasis", "acne", "dermatitis", "skin infection", "cellulitis",
            "ringworm", "athletes foot", "jock itch", "scabies", "lice", "bed bugs",
            "allergic skin reaction", "contact dermatitis", "hives", "shingles",
            "cold sores", "warts", "moles changing", "suspicious skin growth",
            
            # Urinary and reproductive
            "urinary tract infection", "kidney infection", "kidney stones", 
            "urinary incontinence", "painful urination", "frequent urination",
            "blood in urine", "bladder pain", "testicular pain", "vaginal discharge",
            "abnormal menstruation", "menstrual cramps", "yeast infection", "bacterial vaginosis",
            "prostate problems", "erectile dysfunction", "low libido", "sexual dysfunction",
            
            # Vision and hearing
            "vision loss", "hearing loss", "tinnitus", "ringing in ears", "ear infection",
            "vertigo", "dizziness", "light sensitivity", "floaters in vision", "cataracts",
            "glaucoma symptoms", "macular degeneration", "double vision", "earwax buildup",
            "ear discharge", "ear pressure", "itchy ears", "itchy eyes", "eye discharge",
            "pink eye", "dry eyes", "watery eyes", "eye strain", "eye fatigue",
            
            # Immune and autoimmune
            "allergic reaction", "anaphylaxis", "hives", "food allergy", "seasonal allergies",
            "hay fever", "autoimmune symptoms", "lupus symptoms", "rheumatoid arthritis",
            "multiple sclerosis symptoms", "crohns disease", "ulcerative colitis",
            "celiac disease", "hashimotos thyroiditis", "graves disease", "psoriatic arthritis",
            
            # General wellness
            "chronic pain", "chronic fatigue", "malaise", "lethargy", "weakness",
            "dehydration", "malnutrition", "vitamin deficiency", "mineral deficiency",
            "unexplained weight gain", "unexplained weight loss", "fever of unknown origin",
            "night sweats", "general unwellness", "feeling sick", "feeling unwell"
        ]
        
        # Common misspellings of symptoms (expanded)
        self.symptom_misspellings = {
            # Fever related
            "feaver": "fever", "feverr": "fever", "fevr": "fever", "feever": "fever",
            "high temperature": "fever", "running a temperature": "fever", "hot": "fever",
            
            # Headache related
            "hedache": "headache", "headake": "headache", "headacke": "headache",
            "headpain": "headache", "head ache": "headache", "head pain": "headache",
            "migrain": "migraine", "miagraine": "migraine", "migrene": "migraine",
            "migrane": "migraine", "migren": "migraine", "head hurts": "headache",
            
            # Respiratory related
            "caugh": "cough", "coff": "cough", "cofing": "coughing", "caffing": "coughing",
            "cofing up": "coughing", "coughing up": "coughing", "cuffing": "coughing",
            "hackin": "coughing", "hacking cough": "coughing", "dry caugh": "dry cough",
            "wet caugh": "wet cough", "caughing": "coughing", "cauffing": "coughing",
            
            # Cold related
            "flu": "cold", "common cold": "cold", "kold": "cold", "caught a cold": "cold", 
            "have a cold": "cold", "got a cold": "cold", "having a cold": "cold", 
            "feeling sick": "cold", "came down with": "cold", "snotty": "cold",
            "feeling under the weather": "cold", "sniffles": "cold", "rhinitis": "cold",
            "head cold": "cold", "chest cold": "cold", "comon cold": "common cold",
            "stuffed up": "congestion", "stuffed nose": "congestion", "congested": "congestion",
            "blocked nose": "congestion", "cant breathe through nose": "congestion",
            "sinus problems": "sinus pain", "sinusitis": "sinus pain",
            
            # Digestive issues 
            "nauseated": "nausea", "nasia": "nausea", "nasea": "nausea", "feeling sick": "nausea",
            "feel like throwing up": "nausea", "queasy": "nausea", "queezy": "nausea",
            "vomit": "vomiting", "throwing up": "vomiting", "puking": "vomiting", "upchucking": "vomiting",
            "heaving": "vomiting", "regurgitating": "vomiting", "sick up": "vomiting",
            "thowing up": "vomiting", "tossing my cookies": "vomiting", "barfing": "vomiting",
            "diarhea": "diarrhea", "diarea": "diarrhea", "loose stool": "diarrhea", "runny stool": "diarrhea",
            "watery stool": "diarrhea", "loose bowels": "diarrhea", "the runs": "diarrhea",
            "constant bathroom trips": "diarrhea", "frequent bowel movements": "diarrhea",
            "stomache": "stomach pain", "stomach ache": "stomach pain", "belly pain": "stomach pain",
            "tummy pain": "stomach pain", "pain in stomach": "stomach pain", "tummy ache": "stomach pain",
            "stomachache": "stomach pain", "my stomach hurts": "stomach pain", "sore stomach": "stomach pain",
            "abdomen pain": "abdominal pain", "pain in abdomen": "abdominal pain", "sore abdomen": "abdominal pain",
            "acid reflux": "heartburn", "gerd": "heartburn", "burning in chest": "heartburn",
            "burning in throat": "heartburn", "acid indigestion": "heartburn", "hart burn": "heartburn",
            "indijestion": "indigestion", "upset stomach": "indigestion", "dyspepsia": "indigestion",
            "gassy": "gas", "flatulence": "gas", "excessive gas": "gas", "bloated": "bloating",
            "swollen stomach": "bloating", "distended stomach": "bloating", "swollen belly": "bloating",
            "distended abdomen": "bloating", "constipated": "constipation", "cant poop": "constipation",
            "hard stool": "constipation", "difficult bowel movements": "constipation",
            "stomach cramp": "stomach cramps", "abdominal cramp": "abdominal cramps",
            
            # Pain and discomfort
            "chest pain": "chest pain", "heart pain": "chest pain", "pain in chest": "chest pain",
            "angina": "chest pain", "pressure in chest": "chest pain", "chest discomfort": "chest pain",
            "cant breathe": "shortness of breath", "breathing difficulty": "shortness of breath",
            "hard to breathe": "shortness of breath", "trouble breathing": "shortness of breath",
            "out of breath": "shortness of breath", "winded": "shortness of breath",
            "short of breath": "shortness of breath", "dyspnea": "shortness of breath",
            "throatache": "sore throat", "throat pain": "sore throat", "hurt throat": "sore throat",
            "throat hurts": "sore throat", "throat ache": "sore throat", "pharyngitis": "sore throat",
            "pain in throat": "sore throat", "swalowing pain": "sore throat", "itchy throat": "sore throat",
            "muscle ache": "muscle pain", "sore muscles": "muscle pain", "aching muscles": "muscle pain",
            "pain in muscles": "muscle pain", "myalgia": "muscle pain", "muscel pain": "muscle pain",
            "joint ache": "joint pain", "painful joints": "joint pain", "joint pain": "joint pain",
            "arthralgia": "joint pain", "painful joints": "joint pain", "joints hurt": "joint pain",
            "aking joints": "joint pain", "joint discomfort": "joint pain", "jointe pain": "joint pain",
            "backache": "back pain", "sore back": "back pain", "back hurts": "back pain",
            "painful back": "back pain", "back discomfort": "back pain", "bak pain": "back pain",
            "lumbago": "back pain", "back ache": "back pain", "spinal pain": "back pain",
            "lower back pain": "lower back pain", "low back pain": "lower back pain",
            "lumbar pain": "lower back pain", "upper back pain": "upper back pain",
            "pain between shoulders": "upper back pain", "thoracic pain": "upper back pain",
            "neck ache": "neck pain", "pain in neck": "neck pain", "stiff neck": "neck pain",
            "sore neck": "neck pain", "cervical pain": "neck pain", "neckache": "neck pain",
            
            # Fatigue and sleep related
            "fatigued": "fatigue", "tired": "fatigue", "tiredness": "fatigue", "lethargy": "fatigue",
            "exhaustion": "fatigue", "lack of energy": "fatigue", "feeling weak": "fatigue",
            "low energy": "fatigue", "worn out": "fatigue", "run down": "fatigue", "exhausted": "fatigue",
            "dizzy": "dizziness", "diziness": "dizziness", "vertico": "vertigo", "feeling faint": "dizziness",
            "light headed": "lightheadedness", "lightheaded": "lightheadedness", "woozy": "dizziness",
            "spinning": "vertigo", "room spinning": "vertigo", "unsteady": "dizziness",
            "unbalanced": "dizziness", "lose balance": "dizziness", "dizzy spell": "dizziness",
            "can't sleep": "insomnia", "sleeplessness": "insomnia", "unable to sleep": "insomnia",
            "trouble sleeping": "insomnia", "difficulty sleeping": "insomnia", "cant sleep": "insomnia",
            "not sleeping well": "insomnia", "sleep problems": "insomnia", "sleep disturbance": "insomnia",
            "waking up": "insomnia", "interupted sleep": "insomnia", "broken sleep": "insomnia",
            "snorring": "snoring", "loud breathing during sleep": "snoring", "noisy sleep": "snoring",
            "excessive sleeping": "excessive sleeping", "hypersomnia": "excessive sleeping",
            "always tired": "excessive sleeping", "sleeping too much": "excessive sleeping",
            "oversleeping": "excessive sleeping", "cant stay awake": "excessive sleeping",
            
            # Skin related
            "skin rash": "rash", "skin eruption": "rash", "itchy skin": "itching", "itching skin": "itching",
            "red patches": "rash", "skin irritation": "rash", "dermititis": "dermatitis",
            "dermetitis": "dermatitis", "raash": "rash", "small bumps": "rash", "skiin rash": "skin rash",
            "hive": "hives", "urtikaria": "hives", "welts": "hives", "welty": "hives",
            "itchy welts": "hives", "allergic rash": "hives", "itchy rash": "hives",
            "raised bumps": "hives", "red bumps": "hives", "alergic reaction": "allergic reaction",
            
            # Mental health related
            "anxious": "anxiety", "worried": "anxiety", "nervousness": "anxiety", "nervous": "anxiety",
            "excessive worry": "anxiety", "panic": "anxiety", "panick": "anxiety", "anxiet": "anxiety",
            "panick attack": "panic attack", "anxiety attack": "panic attack", "sudden anxiety": "panic attack",
            "depressed": "depression", "feeling down": "depression", "feeling low": "depression",
            "sadness": "depression", "melancholy": "depression", "low mood": "depression",
            "feeling blue": "depression", "despressed": "depression", "helplessness": "depression",
            "no motivation": "depression", "no interest": "depression", "anhedonia": "depression",
            
            # Vision and hearing
            "can't see clearly": "blurred vision", "vision problems": "blurred vision",
            "blurry vision": "blurred vision", "blurry sight": "blurred vision",
            "fuzzy vision": "blurred vision", "unclear vision": "blurred vision",
            "double image": "double vision", "seeing double": "double vision", "diplopia": "double vision",
            "earache": "ear pain", "hurting ear": "ear pain", "ear hurts": "ear pain",
            "pain in ear": "ear pain", "painful ear": "ear pain", "sore ear": "ear pain",
            "ear aches": "ear pain", "ear infection": "ear infection", "inner ear pain": "ear infection",
            "otitis": "ear infection", "ear discharge": "ear discharge", "fluid from ear": "ear discharge",
            "pus from ear": "ear discharge", "draining ear": "ear discharge", "runny ear": "ear discharge",
            "ringing": "tinnitus", "ear ringing": "tinnitus", "buzzing in ear": "tinnitus",
            "noise in ear": "tinnitus", "sounds in ear": "tinnitus", "ear noise": "tinnitus",
            
            # Other common symptoms
            "swolen": "swelling", "swelled": "swelling", "puffy": "swelling", "edema": "swelling",
            "fluid retention": "swelling", "swolen area": "swelling", "swolen joint": "swelling",
            "feels numb": "numbness", "no feeling": "numbness", "numb sensation": "numbness",
            "lost feeling": "numbness", "pins and needles": "tingling", "prickling": "tingling",
            "pins & needles": "tingling", "tinling": "tingling", "tingley": "tingling",
            "parasthesia": "tingling", "prickling sensation": "tingling", "pricking": "tingling",
            "shaking": "tremor", "trembling": "tremor", "involuntary shaking": "tremor",
            "hand trembling": "tremor", "hand shaking": "tremor", "shakiness": "tremor",
            "jitteryness": "tremor", "quiver": "tremor", "fingers shaking": "tremor",
            "sweaty": "sweating", "perspiration": "sweating", "excessive sweating": "sweating",
            "night sweat": "night sweats", "sweating at night": "night sweats", "hyperhidrosis": "sweating",
            "feeling cold": "chills", "shivers": "chills", "chiling": "chills", "feeling chilly": "chills"
        }
        
        # Create a list of stop words but exclude medical terms
        self.stop_words = set(stopwords.words('english'))
        # Remove medical words from stopwords to prevent filtering out symptoms
        medical_keywords = ["pain", "ache", "sore", "feeling", "cant", "cant", "difficulty"]
        self.stop_words = self.stop_words - set(medical_keywords)
    
    def preprocess_text(self, text):
        """
        Basic text preprocessing: lowercase, remove punctuation, tokenize.
        
        Args:
            text (str): Input text to preprocess
            
        Returns:
            list: List of preprocessed tokens
        """
        # Convert to lowercase
        text = text.lower()
        
        # Remove punctuation
        text = text.translate(str.maketrans('', '', string.punctuation))
        
        # Tokenize
        tokens = word_tokenize(text)
        
        # Remove stopwords but keep medical terms
        tokens = [t for t in tokens if t not in self.stop_words or len(t) <= 3]
        
        return tokens
    
    def extract_name(self, text):
        """
        Extract person's name from text using multiple NER techniques,
        including spaCy, NLTK, and regex patterns
        
        Args:
            text (str): Input text containing a name
            
        Returns:
            str: Extracted name or None if not found
        """
        # Method 1: SpaCy NER (if available)
        if nlp:
            # Use spaCy for NER
            doc = nlp(text)
            
            # Look for PERSON entities
            for ent in doc.ents:
                if ent.label_ == "PERSON":
                    return ent.text
            
            # If no entity found, try to extract a proper noun
            for token in doc:
                if token.pos_ == "PROPN":
                    return token.text
        
        # Method 2: NLTK Named Entity Recognition
        try:
            tokens = nltk.word_tokenize(text)
            tagged = nltk.pos_tag(tokens)
            entities = nltk.chunk.ne_chunk(tagged)
            
            for entity in entities:
                if isinstance(entity, nltk.tree.Tree) and entity.label() == 'PERSON':
                    name = ' '.join([leaf[0] for leaf in entity.leaves()])
                    return name
        except Exception as e:
            logger.error(f"NLTK NER error: {str(e)}")
            
        # Method 3: Common name patterns using regex
        # Pattern for "My name is John Smith" or "I am John Smith"
        name_patterns = [
            r'(?:my name is|i am|i\'m|this is|name\'s|call me)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)',
            r'([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\s+(?:here|speaking|is my name)',
            r'^([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)$'  # Just a capitalized name by itself
        ]
        
        for pattern in name_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                # Capitalize the first letter of each word in the name
                name_parts = match.group(1).split()
                capitalized_name = ' '.join([part.capitalize() for part in name_parts])
                return capitalized_name
        
        # Method 4: Fallback to capitalized words
        words = text.split()
        for word in words:
            if len(word) > 1 and word[0].isupper():
                return word
        
        # Final fallback: return the first word
        return text.split()[0] if text else None
    
    def extract_age(self, text):
        """
        Extract age from text
        
        Args:
            text (str): Input text containing an age
            
        Returns:
            int: Extracted age or None if not found
        """
        # Use regex to find patterns like "I am 35 years old" or just "35"
        age_patterns = [
            r'\b(\d{1,3})\s*(?:years|year|yrs|yr)(?:\s*old)?\b',  # "35 years old", "35 years", "35 yr"
            r'\bI\'*\s*a?m\s*(\d{1,3})\b',                       # "I am 35", "I'm 35"
            r'\bage\s*(?:is|of)?\s*(\d{1,3})\b',                 # "age is 35", "age of 35"
            r'\b(\d{1,3})\b'                                      # Just a number
        ]
        
        for pattern in age_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                age = int(match.group(1))
                # Sanity check - age should be reasonable
                if 0 < age < 120:
                    return age
        
        return None
    
    def extract_gender(self, text):
        """
        Extract gender from text
        
        Args:
            text (str): Input text containing gender information
            
        Returns:
            str: "male", "female", or "other"
        """
        text = text.lower()
        
        male_patterns = ['male', 'man', 'boy', 'gentleman', 'm ', 'guy']
        female_patterns = ['female', 'woman', 'girl', 'lady', 'f ', 'gal']
        other_patterns = ['other', 'non-binary', 'nonbinary', 'they', 'them', 'prefer not to say']
        
        # Check for each pattern
        for pattern in male_patterns:
            if pattern in text:
                return "male"
                
        for pattern in female_patterns:
            if pattern in text:
                return "female"
                
        for pattern in other_patterns:
            if pattern in text:
                return "other"
        
        # Default to None if no gender detected
        return None
    
    def correct_spelling(self, word):
        """
        Correct spelling using multiple techniques:
        1. Dictionary lookup
        2. Multiple fuzzy matching algorithms
        3. Phonetic matching (Soundex, Metaphone) 
        4. Edit distance (Levenshtein)
        5. Character n-gram analysis
        
        Args:
            word (str): Word to correct
            
        Returns:
            str: Corrected word
        """
        # Skip very short words to avoid false positives
        if len(word) < 3:
            return word
            
        # Check if word is already in symptoms list
        if word in self.symptoms:
            return word
            
        # Check if word is in misspellings dictionary
        if word in self.symptom_misspellings:
            return self.symptom_misspellings[word]
        
        # Try multiple matching strategies in sequence, from most to least strict

        # 1. High-threshold fuzzy match (most confident)
        match1, score1 = process.extractOne(word, self.symptoms, scorer=fuzz.ratio)
        if score1 >= 85:
            return match1
            
        # 2. Phonetic matching - Soundex (good for missing/added consonants)
        word_soundex = jellyfish.soundex(word)
        for symptom in self.symptoms:
            if word_soundex == jellyfish.soundex(symptom):
                return symptom
        
        # 3. Phonetic matching - Metaphone (alternative phonetic algorithm)
        word_metaphone = jellyfish.metaphone(word)
        for symptom in self.symptoms:
            if word_metaphone == jellyfish.metaphone(symptom):
                return symptom
                
        # 4. Edit distance - Levenshtein (good for 1-2 character errors)
        for symptom in self.symptoms:
            if jellyfish.levenshtein_distance(word, symptom) <= 2:
                return symptom
        
        # 5. Token Sort Ratio (good for word order problems in multi-word symptoms)
        match2, score2 = process.extractOne(word, self.symptoms, scorer=fuzz.token_sort_ratio)
        if score2 >= 70:
            return match2
            
        # 6. Partial Ratio (good for substring matches)
        match3, score3 = process.extractOne(word, self.symptoms, scorer=fuzz.partial_ratio)
        if score3 >= 90:  # Higher threshold since partial matches can be misleading
            return match3
        
        # 7. Check for common prefixes (useful for truncated words)
        if len(word) >= 4:  # Only consider reasonable word lengths
            prefix = word[:4]  # Use first 4 characters as prefix
            matches = []
            for symptom in self.symptoms:
                if symptom.startswith(prefix):
                    matches.append(symptom)
            
            if matches:
                # Find the closest match among prefix matches
                best_match, score = process.extractOne(word, matches, scorer=fuzz.ratio)
                if score >= 60:  # Lower threshold since we already know it has the same prefix
                    return best_match
        
        # 8. Medium-threshold fuzzy match (fallback)
        if score1 >= 70:  # Use the initial fuzzy match, but with lower threshold
            return match1
        
        # Return original word if no correction found
        return word
    
    def extract_symptoms(self, text):
        """
        Extract symptoms from text with spelling correction and enhanced
        matching techniques for misspelled symptoms
        
        Args:
            text (str): Input text describing symptoms
            
        Returns:
            list: List of extracted and corrected symptoms
        """
        tokens = self.preprocess_text(text)
        extracted_symptoms = []
        
        # Pre-check for common symptom phrases and misspellings in whole text
        lower_text = text.lower()
        
        # Direct check for symptom mentions with "having", "experiencing", etc.
        symptom_indicators = [
            r'(?:have|having|suffer|suffering from|experiencing|feel|feeling|got|with|has)\s+([a-z\s]+)',
            r'(?:my|the)\s+([a-z\s]+)\s+(?:hurts|is hurting|is painful|aches|is aching)'
        ]
        
        for pattern in symptom_indicators:
            matches = re.finditer(pattern, lower_text)
            for match in matches:
                described_symptom = match.group(1).strip()
                # Try to match this described symptom to our known symptoms
                best_match, score = process.extractOne(described_symptom, self.symptoms, scorer=fuzz.token_sort_ratio)
                if score >= 80:  # Increased threshold to prevent false positives
                    extracted_symptoms.append(best_match)
        
        # Check for exact matches in the text
        exact_matches = []
        for symptom in self.symptoms:
            if symptom in lower_text:
                exact_matches.append(symptom)
                
        # If we have exact matches, prefer those
        if exact_matches:
            return exact_matches
            
        # Check for symptoms in preprocessed tokens
        for i, token in enumerate(tokens):
            if len(token) < 3:  # Skip very short tokens
                continue
                
            corrected_token = self.correct_spelling(token)
            
            # Check if corrected token is a known symptom (exact match only)
            if corrected_token in self.symptoms:
                extracted_symptoms.append(corrected_token)
                continue
            
            # Check for multi-word symptoms with adjacent tokens (exact match only)
            if i < len(tokens) - 1:
                bigram = token + " " + tokens[i+1]
                if bigram in self.symptoms:
                    extracted_symptoms.append(bigram)
                    continue
                    
                corrected_bigram = self.correct_spelling(bigram)
                if corrected_bigram in self.symptoms:
                    extracted_symptoms.append(corrected_bigram)
            
            if i < len(tokens) - 2:
                trigram = token + " " + tokens[i+1] + " " + tokens[i+2]
                if trigram in self.symptoms:
                    extracted_symptoms.append(trigram)
                    continue
                    
                corrected_trigram = self.correct_spelling(trigram)
                if corrected_trigram in self.symptoms:
                    extracted_symptoms.append(corrected_trigram)
        
        # If we have symptoms from token analysis, return them now
        if extracted_symptoms:
            # Remove duplicates while preserving order
            unique_symptoms = []
            for symptom in extracted_symptoms:
                if symptom not in unique_symptoms:
                    unique_symptoms.append(symptom)
            return unique_symptoms
        
        # Only if no symptoms found with direct methods, try fuzzy matching with high threshold
        for token in tokens:
            if len(token) >= 4:  # Only consider tokens of reasonable length
                # Try fuzzy matching with high threshold
                best_match, score = process.extractOne(token, self.symptoms, scorer=fuzz.ratio)
                if score >= 90:  # Higher threshold to prevent false positives
                    extracted_symptoms.append(best_match)
                    continue
                
                # Try phonetic matching only for exact Soundex matches
                token_soundex = jellyfish.soundex(token)
                for symptom in self.symptoms:
                    if symptom.split()[0] == token and token_soundex == jellyfish.soundex(symptom.split()[0]):
                        extracted_symptoms.append(symptom)
                        break
        
        # Remove duplicates while preserving order
        unique_symptoms = []
        for symptom in extracted_symptoms:
            if symptom not in unique_symptoms:
                unique_symptoms.append(symptom)
        
        return unique_symptoms
    
    def is_symptom_complete(self, text):
        """
        Check if the user has finished describing symptoms
        
        Args:
            text (str): User's message
            
        Returns:
            bool: True if user indicated they're done with symptoms
        """
        completion_indicators = [
            "that's all", "thats all", "that is all", 
            "no more", "nothing else", "done", 
            "finished", "complete", "that's it",
            "thats it", "no other", "no others",
            "no", "none", "nope", "not really", "not any more"
        ]
        
        text_lower = text.lower().strip()
        
        # Check for exact matches like just "no" or "none"
        if text_lower in ["no", "none", "nope"]:
            return True
            
        # Check for phrases containing completion indicators
        for indicator in completion_indicators:
            if indicator in text_lower:
                return True
                
        return False
    
    def is_affirmative(self, text):
        """
        Check if the user's response is affirmative
        
        Args:
            text (str): User's response
            
        Returns:
            bool: True if response is affirmative
        """
        affirmative_responses = [
            "yes", "yeah", "yep", "sure", "ok", "okay", 
            "correct", "right", "that's right", "thats right",
            "that is right", "yup", "absolutely", "indeed"
        ]
        
        text_lower = text.lower()
        for response in affirmative_responses:
            if response in text_lower or fuzz.ratio(response, text_lower) > 80:
                return True
                
        return False
        
    def generate_medical_report(self, user_info, symptoms, predicted_diseases, specialist):
        """
        Generate a comprehensive medical report based on the user's information,
        symptoms, predicted diseases, and recommended specialist.
        
        Args:
            user_info (dict): Dictionary containing user information (name, age, gender)
            symptoms (list): List of symptoms reported by the user
            predicted_diseases (list): List of (disease, probability) tuples
            specialist (str): Recommended medical specialist
            
        Returns:
            str: Formatted medical report as HTML
        """
        # Get current date and time
        from datetime import datetime
        now = datetime.now()
        report_date = now.strftime("%B %d, %Y")
        report_time = now.strftime("%H:%M:%S")
        
        # Format user information
        name = user_info.get('name', 'Unknown')
        age = user_info.get('age', 'Unknown')
        gender = user_info.get('gender', 'Unknown')
        
        # Format symptoms with proper capitalization
        formatted_symptoms = [symptom.capitalize() for symptom in symptoms]
        
        # Format diseases without probabilities/percentages
        formatted_diseases = []
        for disease, _ in predicted_diseases:
            formatted_diseases.append(f"{disease.capitalize()}")
        
        # Build the HTML report
        report_html = f"""
        <div class="medical-report container mt-4 mb-4">
            <div class="card border-0 bg-dark text-light">
                <div class="card-header bg-info text-dark">
                    <h3 class="mb-0">Medical Consultation Report</h3>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <h5 class="text-info">Patient Information</h5>
                            <p><strong>Name:</strong> {name}</p>
                            <p><strong>Age:</strong> {age}</p>
                            <p><strong>Gender:</strong> {gender.capitalize() if gender else 'Unknown'}</p>
                        </div>
                        <div class="col-md-6">
                            <h5 class="text-info">Report Details</h5>
                            <p><strong>Date:</strong> {report_date}</p>
                            <p><strong>Time:</strong> {report_time}</p>
                            <p><strong>Report ID:</strong> MC-{now.strftime('%Y%m%d%H%M%S')}</p>
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <h5 class="text-info">Reported Symptoms</h5>
                        <ul class="list-group list-group-flush bg-dark">
                            {''.join([f'<li class="list-group-item bg-dark text-light border-info">{symptom}</li>' for symptom in formatted_symptoms])}
                        </ul>
                    </div>
                    
                    <div class="mb-4">
                        <h5 class="text-info">Potential Conditions</h5>
                        <p class="text-warning small">Note: This is an AI-generated assessment and not a clinical diagnosis.</p>
                        <ul class="list-group list-group-flush bg-dark">
                            {''.join([f'<li class="list-group-item bg-dark text-light border-info">{disease}</li>' for disease in formatted_diseases])}
                        </ul>
                    </div>
                    
                    <div class="mb-3">
                        <h5 class="text-info">Specialist Recommendation</h5>
                        <p>Based on your symptoms, consultation with a <strong class="text-warning">{specialist}</strong> is recommended.</p>
                    </div>
                    
                    <div class="alert alert-secondary mt-4" role="alert">
                        <strong>Important:</strong> This report is generated by an AI medical assistant and is meant for informational purposes only. 
                        It does not constitute medical advice or replace consultation with a healthcare professional. 
                        Please consult with a qualified physician for proper diagnosis and treatment.
                    </div>
                </div>
                <div class="card-footer text-muted">
                    Generated by Medical Chatbot Assistant | Not for clinical use
                </div>
            </div>
        </div>
        """
        
        return report_html
