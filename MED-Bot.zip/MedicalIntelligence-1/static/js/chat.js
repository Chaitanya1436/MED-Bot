// Chat functionality for the medical assistant
document.addEventListener('DOMContentLoaded', function() {
    const chatContainer = document.getElementById('chat-container');
    const messageForm = document.getElementById('message-form');
    const userInput = document.getElementById('user-input');
    
    // Send initial greeting from the bot
    setTimeout(() => {
        addBotMessage("Hello! I'm your medical assistant. I can help assess your symptoms and recommend appropriate specialists. How can I help you today?");
    }, 500);
    
    // Handle form submission
    messageForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const message = userInput.value.trim();
        if (message.length === 0) return;
        
        // Add user message to chat
        addUserMessage(message);
        
        // Clear input field
        userInput.value = '';
        
        // Show typing indicator
        showTypingIndicator();
        
        // Send message to server
        sendMessage(message);
    });
    
    // Function to add user message to chat
    function addUserMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = 'chat-message user-message';
        messageElement.innerHTML = `
            <div class="message-content">
                <div class="message-text">${formatMessage(message)}</div>
                <div class="message-time">${getCurrentTime()}</div>
            </div>
        `;
        chatContainer.appendChild(messageElement);
        scrollToBottom();
    }
    
    // Function to add bot message to chat
    function addBotMessage(message) {
        // Remove typing indicator if present
        const typingIndicator = document.querySelector('.typing-indicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
        
        const messageElement = document.createElement('div');
        messageElement.className = 'chat-message bot-message';
        messageElement.innerHTML = `
            <div class="message-avatar">
                <i class="fas fa-robot"></i>
            </div>
            <div class="message-content">
                <div class="message-text">${formatMessage(message)}</div>
                <div class="message-time">${getCurrentTime()}</div>
            </div>
        `;
        chatContainer.appendChild(messageElement);
        scrollToBottom();
    }
    
    // Function to show typing indicator
    function showTypingIndicator() {
        const indicatorElement = document.createElement('div');
        indicatorElement.className = 'chat-message bot-message typing-indicator';
        indicatorElement.innerHTML = `
            <div class="message-avatar">
                <i class="fas fa-robot"></i>
            </div>
            <div class="message-content">
                <div class="dot-typing">
                    <span class="dot"></span>
                    <span class="dot"></span>
                    <span class="dot"></span>
                </div>
            </div>
        `;
        chatContainer.appendChild(indicatorElement);
        scrollToBottom();
    }
    
    // Function to send message to server
    function sendMessage(message) {
        fetch('/process_message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message: message }),
        })
        .then(response => response.json())
        .then(data => {
            // Add bot response after a short delay to simulate typing
            setTimeout(() => {
                // Check if response contains a medical report
                if (data.report_html) {
                    addBotMessage(data.response);
                    // After a short delay, add the medical report
                    setTimeout(() => {
                        addMedicalReport(data.report_html);
                    }, 500);
                } else {
                    addBotMessage(data.response);
                }
            }, 1000);
        })
        .catch(error => {
            console.error('Error:', error);
            setTimeout(() => {
                addBotMessage("I'm sorry, I encountered an error processing your message. Please try again.");
            }, 1000);
        });
    }
    
    // Function to add a medical report to the chat
    function addMedicalReport(reportHtml) {
        const reportContainer = document.createElement('div');
        reportContainer.className = 'medical-report-container';
        reportContainer.innerHTML = reportHtml;
        
        // Create a wrapper for the report in the chat flow
        const messageElement = document.createElement('div');
        messageElement.className = 'chat-message bot-message report-message';
        messageElement.innerHTML = `
            <div class="message-avatar">
                <i class="fas fa-file-medical"></i>
            </div>
            <div class="message-content w-100">
                <div class="message-text p-0">
                    <div class="report-header mb-2">
                        <strong>Medical Report</strong>
                        <div class="btn-group btn-group-sm float-end" role="group">
                            <button type="button" class="btn btn-sm btn-outline-info print-report">
                                <i class="fas fa-print"></i> Print
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-info download-report">
                                <i class="fas fa-download"></i> Download
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        chatContainer.appendChild(messageElement);
        
        // Add the report content after the header
        const messageContent = messageElement.querySelector('.message-content');
        messageContent.appendChild(reportContainer);
        
        // Add the current time
        const timeElement = document.createElement('div');
        timeElement.className = 'message-time';
        timeElement.textContent = getCurrentTime();
        messageContent.appendChild(timeElement);
        
        // Add print functionality
        messageElement.querySelector('.print-report').addEventListener('click', function() {
            const printWindow = window.open('', '_blank');
            printWindow.document.write(`
                <html>
                <head>
                    <title>Medical Report</title>
                    <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
                    <style>
                        body { 
                            padding: 20px;
                            background-color: white;
                            color: black;
                        }
                        .card {
                            background-color: white !important;
                            color: black !important;
                        }
                        .card-header {
                            background-color: #0dcaf0 !important;
                            color: black !important;
                        }
                        .text-light {
                            color: black !important;
                        }
                        .list-group-item {
                            background-color: white !important;
                            color: black !important;
                        }
                        .text-info {
                            color: #0dcaf0 !important;
                        }
                        .text-warning {
                            color: #fd7e14 !important;
                        }
                        @media print {
                            .no-print { display: none; }
                        }
                    </style>
                </head>
                <body>
                    ${reportHtml}
                    <div class="text-center mt-4 no-print">
                        <button onclick="window.print()" class="btn btn-primary">Print Report</button>
                    </div>
                </body>
                </html>
            `);
            printWindow.document.close();
        });
        
        // Add download functionality (as HTML file)
        messageElement.querySelector('.download-report').addEventListener('click', function() {
            const htmlContent = `
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Medical Report</title>
                    <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
                    <style>
                        body { 
                            padding: 20px;
                            background-color: white;
                            color: black;
                        }
                        .card {
                            background-color: white !important;
                            color: black !important;
                        }
                        .card-header {
                            background-color: #0dcaf0 !important;
                            color: black !important;
                        }
                        .text-light {
                            color: black !important;
                        }
                        .list-group-item {
                            background-color: white !important;
                            color: black !important;
                        }
                        .text-info {
                            color: #0dcaf0 !important;
                        }
                        .text-warning {
                            color: #fd7e14 !important;
                        }
                    </style>
                </head>
                <body>
                    ${reportHtml}
                </body>
                </html>
            `;
            
            const blob = new Blob([htmlContent], { type: 'text/html' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'medical_report.html';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        });
        
        scrollToBottom();
    }
    
    // Function to get current time
    function getCurrentTime() {
        const now = new Date();
        let hours = now.getHours();
        let minutes = now.getMinutes();
        const ampm = hours >= 12 ? 'PM' : 'AM';
        
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        minutes = minutes < 10 ? '0' + minutes : minutes;
        
        return `${hours}:${minutes} ${ampm}`;
    }
    
    // Function to format message with line breaks and links
    function formatMessage(message) {
        // Replace line breaks with <br>
        let formattedMessage = message.replace(/\n/g, '<br>');
        
        // Convert URLs to clickable links
        formattedMessage = formattedMessage.replace(
            /(https?:\/\/[^\s]+)/g, 
            '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>'
        );
        
        return formattedMessage;
    }
    
    // Function to scroll chat to bottom
    function scrollToBottom() {
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }
    
    // Focus input field when page loads
    userInput.focus();
});
