import os
import logging
from flask import Flask, render_template, request, jsonify, session
import nlp_processor as nlp
import medical_data as med

# Set up logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "medical-chatbot-secret-key")

# Initialize the NLP processor
nlp_proc = nlp.NLPProcessor()

@app.route('/')
def index():
    """Render the main chat interface."""
    # Reset the session when user first visits
    session.clear()
    return render_template('index.html')

@app.route('/process_message', methods=['POST'])
def process_message():
    """Process incoming messages from the user and generate a response."""
    try:
        user_message = request.json.get('message', '').strip()
        
        if not user_message:
            return jsonify({'response': "I couldn't understand that. Could you please try again?"})
        
        # Get or initialize conversation state
        chat_state = session.get('chat_state', {
            'stage': 'greeting',
            'collected_info': {},
            'symptoms': [],
            'confirmed_symptoms': []
        })
        
        # Process the message based on current conversation stage
        response, new_state = process_conversation(user_message, chat_state)
        
        # Update session with new state
        session['chat_state'] = new_state
        
        # Check if response is a dictionary containing report HTML
        if isinstance(response, dict) and 'report_html' in response:
            return jsonify({
                'response': response['text'],
                'report_html': response['report_html']
            })
        else:
            return jsonify({'response': response})
        
    except Exception as e:
        logger.error(f"Error processing message: {str(e)}")
        return jsonify({'response': "Sorry, I encountered an error. Please try again."})

def process_conversation(message, state):
    """
    Process the user message based on the current conversation stage.
    
    Args:
        message (str): The user's message
        state (dict): The current conversation state
    
    Returns:
        tuple: (response_text, updated_state)
    """
    stage = state['stage']
    collected_info = state['collected_info']
    
    # Handle conversation based on current stage
    if stage == 'greeting':
        # Initial greeting, ask for name
        response = "Hello! I'm your medical assistant. I can help assess your symptoms and recommend appropriate specialists. What's your name?"
        state['stage'] = 'get_name'
        
    elif stage == 'get_name':
        # Extract name using NER
        name = nlp_proc.extract_name(message)
        if name:
            collected_info['name'] = name
            response = f"Nice to meet you, {name}! Could you please tell me your age?"
            state['stage'] = 'get_age'
        else:
            # If name extraction fails, use the message as name
            collected_info['name'] = message
            response = f"Nice to meet you, {message}! Could you please tell me your age?"
            state['stage'] = 'get_age'
            
    elif stage == 'get_age':
        # Extract age
        age = nlp_proc.extract_age(message)
        if age:
            collected_info['age'] = age
            response = f"Thank you. And what's your gender (male/female/other)?"
            state['stage'] = 'get_gender'
        else:
            response = "I couldn't understand your age. Please provide a number, for example, '35'."
            
    elif stage == 'get_gender':
        # Process gender
        gender = nlp_proc.extract_gender(message)
        if gender:
            collected_info['gender'] = gender
            response = f"Thank you, {collected_info['name']}. Now, please describe your symptoms or what's bothering you."
            state['stage'] = 'collect_symptoms'
        else:
            response = "I couldn't determine your gender. Please specify if you're male, female, or other."
            
    elif stage == 'collect_symptoms':
        # First check if the user is indicating they're done with symptoms
        if nlp_proc.is_symptom_complete(message):
            # If they have at least one symptom, proceed to confirmation
            if state['symptoms']:
                state['stage'] = 'confirm_symptoms'
                symptom_text = ", ".join(state['symptoms'])
                response = f"Let me confirm: you're experiencing {symptom_text}. Is that correct? (yes/no)"
            else:
                # They said "no" but we don't have any symptoms yet
                response = "I need to know at least one symptom to provide a helpful assessment. Could you please describe what you're experiencing?"
        else:
            # Extract symptoms from user message
            extracted_symptoms = nlp_proc.extract_symptoms(message)
            
            if extracted_symptoms:
                # Add newly extracted symptoms to the list
                state['symptoms'].extend(extracted_symptoms)
                
                # Remove duplicates while preserving order
                unique_symptoms = []
                for symptom in state['symptoms']:
                    if symptom not in unique_symptoms:
                        unique_symptoms.append(symptom)
                state['symptoms'] = unique_symptoms
                
                # If we have enough symptoms, move to confirmation
                if len(state['symptoms']) >= 3:
                    # Start confirming symptoms
                    state['stage'] = 'confirm_symptoms'
                    symptom_text = ", ".join(state['symptoms'])
                    response = f"Let me confirm: you're experiencing {symptom_text}. Is that correct? (yes/no)"
                else:
                    # Ask for more symptoms
                    response = f"I've noted that you're experiencing {', '.join(extracted_symptoms)}. Any other symptoms or discomfort you'd like to mention?"
            else:
                # No symptoms detected
                response = "I couldn't identify any symptoms from what you said. Could you describe your physical discomfort or health concerns more specifically?"
            
    elif stage == 'confirm_symptoms':
        # Check if user confirms symptoms
        if nlp_proc.is_affirmative(message):
            state['confirmed_symptoms'] = state['symptoms']
            
            # Predict disease and specialist
            predicted_diseases = med.predict_diseases(state['confirmed_symptoms'])
            specialist = med.recommend_specialist(predicted_diseases)
            
            # Store prediction results in state for report generation
            state['predicted_diseases'] = predicted_diseases
            state['specialist'] = specialist
            
            # Construct response with predictions (without percentages)
            disease_list = ", ".join([disease for disease, _ in predicted_diseases[:3]])
            
            response = f"Based on your symptoms ({', '.join(state['confirmed_symptoms'])}), " \
                      f"you might be experiencing: {disease_list}.\n\n" \
                      f"I recommend consulting a {specialist}. Remember, this is not a diagnosis, " \
                      f"just a recommendation. Would you like to generate a detailed medical report? (yes/no)"
            state['stage'] = 'generate_report'
        else:
            # User doesn't confirm symptoms
            response = "I apologize for the misunderstanding. Let's try again. Please tell me what symptoms you're experiencing."
            state['symptoms'] = []
            state['stage'] = 'collect_symptoms'
            
    elif stage == 'generate_report':
        # Check if user wants a medical report
        if nlp_proc.is_affirmative(message):
            try:
                # Generate the medical report using the NLP processor
                report_html = nlp_proc.generate_medical_report(
                    state['collected_info'],
                    state['confirmed_symptoms'],
                    state['predicted_diseases'],
                    state['specialist']
                )
                
                # Store the report in the state
                state['medical_report'] = report_html
                
                # Return both the message and the report HTML
                response = {
                    'text': "I've generated a detailed medical report based on our consultation. You can view it below.",
                    'report_html': report_html
                }
            except Exception as e:
                logger.error(f"Error generating report: {str(e)}")
                response = "I'm sorry, there was an error generating your medical report. Would you like to start a new consultation? (yes/no)"
            
            state['stage'] = 'end_conversation'
        else:
            # User doesn't want a report, move to end conversation
            response = "Would you like to start a new consultation? (yes/no)"
            state['stage'] = 'end_conversation'
                
    elif stage == 'end_conversation':
        # Check if user wants to start over
        if nlp_proc.is_affirmative(message):
            # Reset state for new conversation
            state = {
                'stage': 'greeting',
                'collected_info': {},
                'symptoms': [],
                'confirmed_symptoms': []
            }
            response = "Let's start a new consultation. What's your name?"
            state['stage'] = 'get_name'
        else:
            response = "Thank you for using our medical chatbot. Take care and don't hesitate to consult a healthcare professional for proper diagnosis and treatment."
    
    else:
        # Default case for unexpected state
        response = "I'm not sure what to do next. Let's start over. What's your name?"
        state = {
            'stage': 'get_name',
            'collected_info': {},
            'symptoms': [],
            'confirmed_symptoms': []
        }
    
    return response, state

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
